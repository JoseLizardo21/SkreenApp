// SPDX-License-Identifier: GPL-2.0+

#include <linux/dma-fence.h>

#include <drm/drm_atomic.h>
#include <drm/drm_atomic_helper.h>
#include <drm/drm_print.h>
#include <drm/drm_probe_helper.h>
#include <drm/drm_vblank.h>

#include "skreen_drv.h"

static enum hrtimer_restart skreen_vblank_simulate(struct hrtimer *timer)
{
	struct skreen_output *output = container_of(timer, struct skreen_output,
						  vblank_hrtimer);
	struct drm_crtc *crtc = &output->crtc;
	struct skreen_crtc_state *state;
	u64 ret_overrun;
	bool ret, fence_cookie;

	fence_cookie = dma_fence_begin_signalling();

	ret_overrun = hrtimer_forward_now(&output->vblank_hrtimer,
					  output->period_ns);
	if (ret_overrun != 1)
		pr_warn("%s: vblank timer overrun\n", __func__);

	spin_lock(&output->lock);
	ret = drm_crtc_handle_vblank(crtc);
	if (!ret)
		drm_err(crtc->dev, "skreen failure on handling vblank");

	state = output->composer_state;
	spin_unlock(&output->lock);

	if (state && output->composer_enabled) {
		u64 frame = drm_crtc_accurate_vblank_count(crtc);

		/* update frame_start only if a queued skreen_composer_worker()
		 * has read the data
		 */
		spin_lock(&output->composer_lock);
		if (!state->crc_pending)
			state->frame_start = frame;
		else
			drm_dbg_driver(crtc->dev,
					 "crc worker falling behind, frame_start: %llu, frame_end: %llu\n",
					 state->frame_start, frame);
		state->frame_end = frame;
		state->crc_pending = true;
		spin_unlock(&output->composer_lock);

		ret = queue_work(output->composer_workq, &state->composer_work);
		if (!ret)
			drm_dbg_driver(crtc->dev, "Composer worker already queued\n");
	}

	dma_fence_end_signalling(fence_cookie);

	return HRTIMER_RESTART;
}

static int skreen_enable_vblank(struct drm_crtc *crtc)
{
	struct drm_vblank_crtc *vblank = drm_crtc_vblank_crtc(crtc);
	struct skreen_output *out = drm_crtc_to_skreen_output(crtc);

	hrtimer_setup(&out->vblank_hrtimer, skreen_vblank_simulate, CLOCK_MONOTONIC, HRTIMER_MODE_REL);
	out->vblank_hrtimer.function = &skreen_vblank_simulate;
	out->period_ns = ktime_set(0, vblank->framedur_ns);
	hrtimer_start(&out->vblank_hrtimer, out->period_ns, HRTIMER_MODE_REL);

	return 0;
}

static void skreen_disable_vblank(struct drm_crtc *crtc)
{
	struct skreen_output *out = drm_crtc_to_skreen_output(crtc);

	hrtimer_cancel(&out->vblank_hrtimer);
}

static bool skreen_get_vblank_timestamp(struct drm_crtc *crtc,
				      int *max_error, ktime_t *vblank_time,
				      bool in_vblank_irq)
{
	struct drm_device *dev = crtc->dev;
	struct skreen_device *vkmsdev = drm_device_to_skreen_device(dev);
	struct skreen_output *output = &vkmsdev->output;
	struct drm_vblank_crtc *vblank = drm_crtc_vblank_crtc(crtc);

	if (!READ_ONCE(vblank->enabled)) {
		*vblank_time = ktime_get();
		return true;
	}

	*vblank_time = READ_ONCE(output->vblank_hrtimer.node.expires);

	if (WARN_ON(*vblank_time == vblank->time))
		return true;

	/*
	 * To prevent races we roll the hrtimer forward before we do any
	 * interrupt processing - this is how real hw works (the interrupt is
	 * only generated after all the vblank registers are updated) and what
	 * the vblank core expects. Therefore we need to always correct the
	 * timestampe by one frame.
	 */
	*vblank_time -= output->period_ns;

	return true;
}

static struct drm_crtc_state *
skreen_atomic_crtc_duplicate_state(struct drm_crtc *crtc)
{
	struct skreen_crtc_state *skreen_state;

	if (WARN_ON(!crtc->state))
		return NULL;

	skreen_state = kzalloc(sizeof(*skreen_state), GFP_KERNEL);
	if (!skreen_state)
		return NULL;

	__drm_atomic_helper_crtc_duplicate_state(crtc, &skreen_state->base);

	INIT_WORK(&skreen_state->composer_work, skreen_composer_worker);

	return &skreen_state->base;
}

static void skreen_atomic_crtc_destroy_state(struct drm_crtc *crtc,
					   struct drm_crtc_state *state)
{
	struct skreen_crtc_state *skreen_state = to_skreen_crtc_state(state);

	__drm_atomic_helper_crtc_destroy_state(state);

	WARN_ON(work_pending(&skreen_state->composer_work));
	kfree(skreen_state->active_planes);
	kfree(skreen_state);
}

static void skreen_atomic_crtc_reset(struct drm_crtc *crtc)
{
	struct skreen_crtc_state *skreen_state =
		kzalloc(sizeof(*skreen_state), GFP_KERNEL);

	if (crtc->state)
		skreen_atomic_crtc_destroy_state(crtc, crtc->state);

	__drm_atomic_helper_crtc_reset(crtc, &skreen_state->base);
	if (skreen_state)
		INIT_WORK(&skreen_state->composer_work, skreen_composer_worker);
}

static const struct drm_crtc_funcs skreen_crtc_funcs = {
	.set_config             = drm_atomic_helper_set_config,
	.page_flip              = drm_atomic_helper_page_flip,
	.reset                  = skreen_atomic_crtc_reset,
	.atomic_duplicate_state = skreen_atomic_crtc_duplicate_state,
	.atomic_destroy_state   = skreen_atomic_crtc_destroy_state,
	.enable_vblank		= skreen_enable_vblank,
	.disable_vblank		= skreen_disable_vblank,
	.get_vblank_timestamp	= skreen_get_vblank_timestamp,
	.get_crc_sources	= skreen_get_crc_sources,
	.set_crc_source		= skreen_set_crc_source,
	.verify_crc_source	= skreen_verify_crc_source,
};

static int skreen_crtc_atomic_check(struct drm_crtc *crtc,
				  struct drm_atomic_state *state)
{
	struct drm_crtc_state *crtc_state = drm_atomic_get_new_crtc_state(state,
									  crtc);
	struct skreen_crtc_state *skreen_state = to_skreen_crtc_state(crtc_state);
	struct drm_plane *plane;
	struct drm_plane_state *plane_state;
	int i = 0, ret;

	/* Free previously allocated active_planes array to rebuild for new state */
	kfree(skreen_state->active_planes);
	skreen_state->active_planes = NULL;

	ret = drm_atomic_add_affected_planes(crtc_state->state, crtc);
	if (ret < 0)
		return ret;

	drm_for_each_plane_mask(plane, crtc->dev, crtc_state->plane_mask) {
		plane_state = drm_atomic_get_new_plane_state(crtc_state->state, plane);
		WARN_ON(!plane_state);

		if (!plane_state->visible)
			continue;

		i++;
	}

	skreen_state->active_planes = kcalloc(i, sizeof(plane), GFP_KERNEL);
	if (!skreen_state->active_planes)
		return -ENOMEM;
	skreen_state->num_active_planes = i;

	i = 0;
	drm_for_each_plane_mask(plane, crtc->dev, crtc_state->plane_mask) {
		plane_state = drm_atomic_get_new_plane_state(crtc_state->state, plane);

		if (!plane_state->visible)
			continue;

		skreen_state->active_planes[i++] =
			to_skreen_plane_state(plane_state);
	}

	return 0;
}

static void skreen_crtc_atomic_enable(struct drm_crtc *crtc,
				    struct drm_atomic_state *state)
{
	drm_crtc_vblank_on(crtc);
}

static void skreen_crtc_atomic_disable(struct drm_crtc *crtc,
				     struct drm_atomic_state *state)
{
	drm_crtc_vblank_off(crtc);
}

static void skreen_crtc_atomic_begin(struct drm_crtc *crtc,
				   struct drm_atomic_state *state)
	__acquires(&skreen_output->lock)
{
	struct skreen_output *skreen_output = drm_crtc_to_skreen_output(crtc);

	/* This lock is held across the atomic commit to block vblank timer
	 * from scheduling skreen_composer_worker until the composer is updated
	 */
	spin_lock_irq(&skreen_output->lock);
}

static void skreen_crtc_atomic_flush(struct drm_crtc *crtc,
				   struct drm_atomic_state *state)
	__releases(&skreen_output->lock)
{
	struct skreen_output *skreen_output = drm_crtc_to_skreen_output(crtc);

	if (crtc->state->event) {
		spin_lock(&crtc->dev->event_lock);

		if (drm_crtc_vblank_get(crtc) != 0)
			drm_crtc_send_vblank_event(crtc, crtc->state->event);
		else
			drm_crtc_arm_vblank_event(crtc, crtc->state->event);

		spin_unlock(&crtc->dev->event_lock);

		crtc->state->event = NULL;
	}

	skreen_output->composer_state = to_skreen_crtc_state(crtc->state);

	spin_unlock_irq(&skreen_output->lock);
}

static const struct drm_crtc_helper_funcs skreen_crtc_helper_funcs = {
	.atomic_check	= skreen_crtc_atomic_check,
	.atomic_begin	= skreen_crtc_atomic_begin,
	.atomic_flush	= skreen_crtc_atomic_flush,
	.atomic_enable	= skreen_crtc_atomic_enable,
	.atomic_disable	= skreen_crtc_atomic_disable,
};

int skreen_crtc_init(struct drm_device *dev, struct drm_crtc *crtc,
		   struct drm_plane *primary, struct drm_plane *cursor)
{
	struct skreen_output *skreen_out = drm_crtc_to_skreen_output(crtc);
	int ret;

	ret = drmm_crtc_init_with_planes(dev, crtc, primary, cursor,
					 &skreen_crtc_funcs, NULL);
	if (ret) {
		drm_err(dev, "Failed to init CRTC\n");
		return ret;
	}

	drm_crtc_helper_add(crtc, &skreen_crtc_helper_funcs);

	ret = drm_mode_crtc_set_gamma_size(crtc, SKREEN_LUT_SIZE);
	if (ret) {
		drm_err(dev, "Failed to set gamma size\n");
		return ret;
	}

	drm_crtc_enable_color_mgmt(crtc, 0, false, SKREEN_LUT_SIZE);

	spin_lock_init(&skreen_out->lock);
	spin_lock_init(&skreen_out->composer_lock);

	skreen_out->composer_workq = alloc_ordered_workqueue("skreen_composer", 0);
	if (!skreen_out->composer_workq)
		return -ENOMEM;

	return ret;
}
