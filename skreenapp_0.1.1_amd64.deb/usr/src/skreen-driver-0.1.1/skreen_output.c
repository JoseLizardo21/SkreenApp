// SPDX-License-Identifier: GPL-2.0+

#include "skreen_drv.h"
#include <drm/drm_atomic_helper.h>
#include <drm/drm_edid.h>
#include <drm/drm_print.h>
#include <drm/drm_probe_helper.h>

static const struct drm_connector_funcs skreen_connector_funcs = {
	.fill_modes = drm_helper_probe_single_connector_modes,
	.destroy = drm_connector_cleanup,
	.reset = drm_atomic_helper_connector_reset,
	.atomic_duplicate_state = drm_atomic_helper_connector_duplicate_state,
	.atomic_destroy_state = drm_atomic_helper_connector_destroy_state,
};

static const struct drm_encoder_funcs skreen_encoder_funcs = {
	.destroy = drm_encoder_cleanup,
};

static bool skreen_encoder_mode_fixup(struct drm_encoder *encoder,
				       const struct drm_display_mode *mode,
				       struct drm_display_mode *adjusted_mode)
{
	/* Accept all modes for virtual encoder */
	return true;
}

static const struct drm_encoder_helper_funcs skreen_encoder_helper_funcs = {
	.mode_fixup = skreen_encoder_mode_fixup,
};

/*
 * Common landscape resolutions always offered by the connector. Resolutions
 * added via DRM_IOCTL_SKREEN_ADD_RESOLUTION are reported after these.
 */
static const struct skreen_mode_preset skreen_mobile_mode_presets[] = {
	/* Common smartphone resolutions (landscape) */
	{ 1280, 720 },  /* HD */
	{ 1334, 750 },  /* iPhone 6/7/8 */
	{ 1600, 720 },  /* HD+ */
	{ 1920, 1080 }, /* Full HD */
	{ 2220, 1080 }, /* FHD+ 18.5:9 */
	{ 2280, 1080 }, /* FHD+ 19:9 */
	{ 2340, 1080 }, /* FHD+ 19.5:9, e.g. Galaxy S10/S20 */
	{ 2400, 1080 }, /* FHD+ 20:9, e.g. Galaxy S21/S22 */

	/* Common tablet resolutions (landscape) */
	{ 1024, 768 },  /* XGA 4:3, e.g. iPad */
	{ 1280, 800 },  /* WXGA 16:10, e.g. Nexus 7 */
	{ 1366, 768 },  /* HD 16:9, common budget tablet */
	{ 1600, 900 },  /* HD+ 16:9 tablet */
	{ 2160, 1080 }, /* FHD+ 18:9 tablet */
};

/*
 * EDID 1.4 base block identifying the monitor to userspace. Without an EDID,
 * GNOME shows the connector as "Unknown Display"; with it, mutter builds the
 * name "<vendor> <product>" (e.g. "SKR Skreen").
 *
 * The screen size is 16 x 9 cm on purpose: mutter treats 160x90 mm as an
 * aspect ratio rather than a real size, so it uses the product name instead
 * of "<vendor> <diagonal inches>" and does not derive a scale from it.
 *
 * No timings are listed; modes come from skreen_conn_get_modes(). The
 * checksum (byte 127) is filled in by skreen_conn_update_edid().
 */
static const u8 skreen_edid_template[EDID_LENGTH] = {
	/* Header */
	0x00, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0x00,
	/* Manufacturer "SKR", product code 0x0001, serial 0 */
	0x4d, 0x72, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00,
	/* Week 1 of 2026, EDID 1.4, digital input, 16 x 9 cm, gamma 2.2, features */
	0x01, 0x24, 0x01, 0x04, 0x80, 0x10, 0x09, 0x78, 0x00,
	/* Chromaticity (unspecified) */
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	/* Established timings (none) */
	0x00, 0x00, 0x00,
	/* Standard timings (unused) */
	0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01,
	0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01,
	/* Display product name descriptor: "Skreen" */
	0x00, 0x00, 0x00, 0xfc, 0x00,
	'S', 'k', 'r', 'e', 'e', 'n', 0x0a, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20,
	/* Dummy descriptors */
	0x00, 0x00, 0x00, 0x10, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x10, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x10, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	/* No extensions, checksum */
	0x00, 0x00,
};

/*
 * Publishes the EDID (and the display info derived from it) while the monitor
 * is enabled, and clears it while disabled. Called from get_modes(), so
 * mode_config.mutex is held.
 */
static void skreen_conn_update_edid(struct drm_connector *connector, bool enabled)
{
	const struct drm_edid *drm_edid;
	u8 edid[EDID_LENGTH];
	u8 sum = 0;
	unsigned int i;

	if (!enabled) {
		drm_edid_connector_update(connector, NULL);
		return;
	}

	memcpy(edid, skreen_edid_template, sizeof(edid));
	for (i = 0; i < EDID_LENGTH - 1; i++)
		sum += edid[i];
	edid[EDID_LENGTH - 1] = 0x100 - sum;

	drm_edid = drm_edid_alloc(edid, sizeof(edid));
	drm_edid_connector_update(connector, drm_edid);
	drm_edid_free(drm_edid);
}

static bool skreen_mode_listed(struct skreen_device *vkmsdev, u16 width, u16 height)
{
	unsigned int i;

	for (i = 0; i < ARRAY_SIZE(skreen_mobile_mode_presets); i++) {
		if (skreen_mobile_mode_presets[i].width == width &&
		    skreen_mobile_mode_presets[i].height == height)
			return true;
	}

	for (i = 0; i < vkmsdev->num_extra_modes; i++) {
		if (vkmsdev->extra_modes[i].width == width &&
		    vkmsdev->extra_modes[i].height == height)
			return true;
	}

	return false;
}

int skreen_output_add_mode(struct skreen_device *vkmsdev, u16 width, u16 height)
{
	struct drm_device *dev = &vkmsdev->drm;
	int ret = 0;

	mutex_lock(&dev->mode_config.mutex);

	if (skreen_mode_listed(vkmsdev, width, height)) {
		ret = -EEXIST;
	} else if (vkmsdev->num_extra_modes >= SKREEN_MAX_EXTRA_MODES) {
		ret = -ENOSPC;
	} else {
		vkmsdev->extra_modes[vkmsdev->num_extra_modes].width = width;
		vkmsdev->extra_modes[vkmsdev->num_extra_modes].height = height;
		vkmsdev->num_extra_modes++;
	}

	mutex_unlock(&dev->mode_config.mutex);

	return ret;
}

static struct drm_display_mode *skreen_build_mode(struct drm_connector *connector,
						    int hdisplay, int vdisplay,
						    bool preferred)
{
	struct drm_display_mode *mode = drm_mode_create(connector->dev);

	if (!mode)
		return NULL;

	mode->hdisplay = hdisplay;
	mode->vdisplay = vdisplay;
	mode->hsync_start = hdisplay + 40;
	mode->hsync_end = hdisplay + 80;
	mode->htotal = hdisplay + 120;
	mode->vsync_start = vdisplay + 5;
	mode->vsync_end = vdisplay + 10;
	mode->vtotal = vdisplay + 25;
	mode->clock = 60 * mode->htotal * mode->vtotal / 1000;
	mode->type = DRM_MODE_TYPE_DRIVER;
	if (preferred)
		mode->type |= DRM_MODE_TYPE_PREFERRED;

	drm_mode_set_name(mode);

	return mode;
}

static int skreen_add_probed_mode(struct drm_connector *connector,
				  const struct skreen_mode_preset *preset)
{
	bool preferred = preset->width == XRES_DEF && preset->height == YRES_DEF;
	struct drm_display_mode *mode;

	mode = skreen_build_mode(connector, preset->width, preset->height, preferred);
	if (!mode)
		return 0;

	drm_mode_probed_add(connector, mode);

	return 1;
}

static int skreen_conn_get_modes(struct drm_connector *connector)
{
	struct skreen_output *output = container_of(connector, struct skreen_output, connector);
	struct skreen_device *dev = container_of(output, struct skreen_device, output);
	int count = 0;
	unsigned int i;

	skreen_conn_update_edid(connector, dev->enabled);

	/* Only provide modes if the display is enabled */
	if (!dev->enabled) {
		return 0;
	}

	/*
	 * Offer the built-in smartphone/tablet presets, then any resolution
	 * added via DRM_IOCTL_SKREEN_ADD_RESOLUTION. The user picks among them
	 * from their display settings; XRES_DEF x YRES_DEF is marked preferred
	 * so compositors default to it.
	 */
	for (i = 0; i < ARRAY_SIZE(skreen_mobile_mode_presets); i++)
		count += skreen_add_probed_mode(connector, &skreen_mobile_mode_presets[i]);

	for (i = 0; i < dev->num_extra_modes; i++)
		count += skreen_add_probed_mode(connector, &dev->extra_modes[i]);

	return count;
}

static enum drm_connector_status skreen_conn_detect(struct drm_connector *connector,
						      bool force)
{
	struct skreen_output *output = container_of(connector, struct skreen_output, connector);
	struct skreen_device *dev = container_of(output, struct skreen_device, output);

	/* Return disconnected if the display is disabled */
	if (!dev->enabled)
		return connector_status_disconnected;

	return connector_status_connected;
}

static const struct drm_connector_helper_funcs skreen_conn_helper_funcs = {
	.get_modes    = skreen_conn_get_modes,
};

static const struct drm_connector_funcs skreen_connector_funcs_updated = {
	.fill_modes = drm_helper_probe_single_connector_modes,
	.destroy = drm_connector_cleanup,
	.reset = drm_atomic_helper_connector_reset,
	.atomic_duplicate_state = drm_atomic_helper_connector_duplicate_state,
	.atomic_destroy_state = drm_atomic_helper_connector_destroy_state,
	.detect = skreen_conn_detect,
};

int skreen_output_init(struct skreen_device *vkmsdev)
{
	struct skreen_output *output = &vkmsdev->output;
	struct drm_device *dev = &vkmsdev->drm;
	struct drm_connector *connector = &output->connector;
	struct drm_encoder *encoder = &output->encoder;
	struct drm_crtc *crtc = &output->crtc;
	struct skreen_plane *primary, *overlay, *cursor = NULL;
	int ret;
	int writeback;
	unsigned int n;

	/*
	 * Initialize used plane. One primary plane is required to perform the composition.
	 *
	 * The overlay and cursor planes are not mandatory, but can be used to perform complex
	 * composition.
	 */
	primary = skreen_plane_init(vkmsdev, DRM_PLANE_TYPE_PRIMARY);
	if (IS_ERR(primary))
		return PTR_ERR(primary);

	if (vkmsdev->config->cursor) {
		cursor = skreen_plane_init(vkmsdev, DRM_PLANE_TYPE_CURSOR);
		if (IS_ERR(cursor))
			return PTR_ERR(cursor);
	}

	ret = skreen_crtc_init(dev, crtc, &primary->base, &cursor->base);
	if (ret)
		return ret;

	if (vkmsdev->config->overlay) {
		for (n = 0; n < NUM_OVERLAY_PLANES; n++) {
			overlay = skreen_plane_init(vkmsdev, DRM_PLANE_TYPE_OVERLAY);
			if (IS_ERR(overlay)) {
				drm_err(dev, "Failed to init skreen plane\n");
				return PTR_ERR(overlay);
			}
			overlay->base.possible_crtcs = drm_crtc_mask(crtc);
		}
	}

	ret = drm_connector_init(dev, connector, &skreen_connector_funcs_updated,
				 DRM_MODE_CONNECTOR_VIRTUAL);
	if (ret) {
		drm_err(dev, "Failed to init connector\n");
		return ret;
	}

	/*
	 * drm_connector_init() skips the EDID property for virtual connectors,
	 * which would keep the EDID set in get_modes() hidden from userspace.
	 */
	drm_object_attach_property(&connector->base, dev->mode_config.edid_property, 0);

	/* Status changes come from DRM_IOCTL_SKREEN_SET_ENABLED, handled as HPD */
	connector->polled = DRM_CONNECTOR_POLL_HPD;

	drm_connector_helper_add(connector, &skreen_conn_helper_funcs);

	ret = drm_encoder_init(dev, encoder, &skreen_encoder_funcs,
			       DRM_MODE_ENCODER_VIRTUAL, NULL);
	if (ret) {
		drm_err(dev, "Failed to init encoder\n");
		goto err_encoder;
	}
	encoder->possible_crtcs = drm_crtc_mask(crtc);
	drm_encoder_helper_add(encoder, &skreen_encoder_helper_funcs);

	ret = drm_connector_attach_encoder(connector, encoder);
	if (ret) {
		drm_err(dev, "Failed to attach connector to encoder\n");
		goto err_attach;
	}

	if (vkmsdev->config->writeback) {
		writeback = skreen_enable_writeback_connector(vkmsdev);
		if (writeback)
			drm_err(dev, "Failed to init writeback connector\n");
	}

	drm_mode_config_reset(dev);

	return 0;

err_attach:
	drm_encoder_cleanup(encoder);

err_encoder:
	drm_connector_cleanup(connector);

	return ret;
}
