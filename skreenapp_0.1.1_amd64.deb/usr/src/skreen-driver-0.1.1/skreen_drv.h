/* SPDX-License-Identifier: GPL-2.0+ */

#ifndef _VKMS_DRV_H_
#define _VKMS_DRV_H_

#include <linux/hrtimer.h>

#include <drm/drm.h>
#include <drm/drm_framebuffer.h>
#include <drm/drm_gem.h>
#include <drm/drm_gem_atomic_helper.h>
#include <drm/drm_encoder.h>
#include <drm/drm_writeback.h>

/* Kernel 7.2 renamed struct drm_atomic_state to struct drm_atomic_commit */
#ifdef SKREEN_HAVE_DRM_ATOMIC_COMMIT
#define drm_atomic_state drm_atomic_commit
#endif

#define XRES_MIN    10
#define YRES_MIN    10

/* Preferred mode; must be one of the connector's built-in presets */
#define XRES_DEF  1920
#define YRES_DEF  1080

#define XRES_MAX  2400
#define YRES_MAX  1080

#define NUM_OVERLAY_PLANES 8

/* Upper bound on resolutions added at runtime via DRM_IOCTL_SKREEN_ADD_RESOLUTION */
#define SKREEN_MAX_EXTRA_MODES 32

#define SKREEN_LUT_SIZE 256

/**
 * struct skreen_frame_info - Structure to store the state of a frame
 *
 * @fb: backing drm framebuffer
 * @src: source rectangle of this frame in the source framebuffer, stored in 16.16 fixed-point form
 * @dst: destination rectangle in the crtc buffer, stored in whole pixel units
 * @map: see @drm_shadow_plane_state.data
 * @rotation: rotation applied to the source.
 *
 * @src and @dst should have the same size modulo the rotation.
 */
struct skreen_frame_info {
	struct drm_framebuffer *fb;
	struct drm_rect src, dst;
	struct iosys_map map[DRM_FORMAT_MAX_PLANES];
	unsigned int rotation;
};

struct pixel_argb_u16 {
	u16 a, r, g, b;
};

struct line_buffer {
	size_t n_pixels;
	struct pixel_argb_u16 *pixels;
};

/**
 * typedef pixel_write_t - These functions are used to read a pixel from a
 * &struct pixel_argb_u16, convert it in a specific format and write it in the @out_pixel
 * buffer.
 *
 * @out_pixel: destination address to write the pixel
 * @in_pixel: pixel to write
 */
typedef void (*pixel_write_t)(u8 *out_pixel, const struct pixel_argb_u16 *in_pixel);

struct skreen_writeback_job {
	struct iosys_map data[DRM_FORMAT_MAX_PLANES];
	struct skreen_frame_info wb_frame_info;
	pixel_write_t pixel_write;
};

/**
 * enum pixel_read_direction - Enum used internally by VKMS to represent a reading direction in a
 * plane.
 */
enum pixel_read_direction {
	READ_BOTTOM_TO_TOP,
	READ_TOP_TO_BOTTOM,
	READ_RIGHT_TO_LEFT,
	READ_LEFT_TO_RIGHT
};

struct skreen_plane_state;

/**
 * typedef pixel_read_line_t - These functions are used to read a pixel line in the source frame,
 * convert it to `struct pixel_argb_u16` and write it to @out_pixel.
 *
 * @plane: plane used as source for the pixel value
 * @x_start: X (width) coordinate of the first pixel to copy. The caller must ensure that x_start
 * is non-negative and smaller than @plane->frame_info->fb->width.
 * @y_start: Y (height) coordinate of the first pixel to copy. The caller must ensure that y_start
 * is non-negative and smaller than @plane->frame_info->fb->height.
 * @direction: direction to use for the copy, starting at @x_start/@y_start
 * @count: number of pixels to copy
 * @out_pixel: pointer where to write the pixel values. They will be written from @out_pixel[0]
 * (included) to @out_pixel[@count] (excluded). The caller must ensure that out_pixel have a
 * length of at least @count.
 */
typedef void (*pixel_read_line_t)(const struct skreen_plane_state *plane, int x_start,
				  int y_start, enum pixel_read_direction direction, int count,
				  struct pixel_argb_u16 out_pixel[]);

/**
 * struct skreen_plane_state - Driver specific plane state
 * @base: base plane state
 * @frame_info: data required for composing computation
 * @pixel_read_line: function to read a pixel line in this plane. The creator of a
 *		     struct skreen_plane_state must ensure that this pointer is valid
 */
struct skreen_plane_state {
	struct drm_shadow_plane_state base;
	struct skreen_frame_info *frame_info;
	pixel_read_line_t pixel_read_line;
};

struct skreen_plane {
	struct drm_plane base;
};

struct skreen_color_lut {
	struct drm_color_lut *base;
	size_t lut_length;
	s64 channel_value2index_ratio;
};

/**
 * struct skreen_crtc_state - Driver specific CRTC state
 *
 * @base: base CRTC state
 * @composer_work: work struct to compose and add CRC entries
 *
 * @num_active_planes: Number of active planes
 * @active_planes: List containing all the active planes (counted by
 *		   @num_active_planes). They should be stored in z-order.
 * @active_writeback: Current active writeback job
 * @gamma_lut: Look up table for gamma used in this CRTC
 * @crc_pending: Protected by @skreen_output.composer_lock, true when the frame CRC is not computed
 *		 yet. Used by vblank to detect if the composer is too slow.
 * @wb_pending: Protected by @skreen_output.composer_lock, true when a writeback frame is requested.
 * @frame_start: Protected by @skreen_output.composer_lock, saves the frame number before the start
 *		 of the composition process.
 * @frame_end: Protected by @skreen_output.composer_lock, saves the last requested frame number.
 *	       This is used to generate enough CRC entries when the composition worker is too slow.
 */
struct skreen_crtc_state {
	struct drm_crtc_state base;
	struct work_struct composer_work;

	int num_active_planes;
	struct skreen_plane_state **active_planes;
	struct skreen_writeback_job *active_writeback;
	struct skreen_color_lut gamma_lut;

	bool crc_pending;
	bool wb_pending;
	u64 frame_start;
	u64 frame_end;
};

/**
 * struct skreen_output - Internal representation of all output components in VKMS
 *
 * @crtc: Base CRTC in DRM
 * @encoder: DRM encoder used for this output
 * @connector: DRM connector used for this output
 * @wb_connecter: DRM writeback connector used for this output
 * @vblank_hrtimer: Timer used to trigger the vblank
 * @period_ns: vblank period, in nanoseconds, used to configure @vblank_hrtimer and to compute
 *	       vblank timestamps
 * @composer_workq: Ordered workqueue for @composer_state.composer_work.
 * @lock: Lock used to protect concurrent access to the composer
 * @composer_enabled: Protected by @lock, true when the VKMS composer is active (crc needed or
 *		      writeback)
 * @composer_state: Protected by @lock, current state of this VKMS output
 * @composer_lock: Lock used internally to protect @composer_state members
 */
struct skreen_output {
	struct drm_crtc crtc;
	struct drm_encoder encoder;
	struct drm_connector connector;
	struct drm_writeback_connector wb_connector;
	struct hrtimer vblank_hrtimer;
	ktime_t period_ns;
	struct workqueue_struct *composer_workq;
	spinlock_t lock;

	bool composer_enabled;
	struct skreen_crtc_state *composer_state;

	spinlock_t composer_lock;
};

/**
 * struct skreen_config - General configuration for VKMS driver
 *
 * @writeback: If true, a writeback buffer can be attached to the CRTC
 * @cursor: If true, a cursor plane is created in the VKMS device
 * @overlay: If true, NUM_OVERLAY_PLANES will be created for the VKMS device
 * @dev: Used to store the current VKMS device. Only set when the device is instantiated.
 */
struct skreen_config {
	bool writeback;
	bool cursor;
	bool overlay;
	struct skreen_device *dev;
};

/**
 * struct skreen_mode_preset - A resolution offered by the skreen connector
 *
 * All entries must fit within [XRES_MIN, XRES_MAX] x [YRES_MIN, YRES_MAX].
 */
struct skreen_mode_preset {
	u16 width;
	u16 height;
};

/**
 * struct skreen_device - Description of a VKMS device
 *
 * @drm - Base device in DRM
 * @platform - Associated platform device
 * @output - Configuration and sub-components of the VKMS device
 * @config: Configuration used in this VKMS device
 * @enabled - Whether the virtual display is enabled (controlled via ioctl).
 *	      Protected by drm.mode_config.mutex.
 * @extra_modes - Resolutions added via DRM_IOCTL_SKREEN_ADD_RESOLUTION, reported
 *		  by the connector alongside the built-in presets. Protected by
 *		  drm.mode_config.mutex.
 * @num_extra_modes - Number of valid entries in @extra_modes
 */
struct skreen_device {
	struct drm_device drm;
	struct platform_device *platform;
	struct skreen_output output;
	const struct skreen_config *config;
	bool enabled;
	struct skreen_mode_preset extra_modes[SKREEN_MAX_EXTRA_MODES];
	unsigned int num_extra_modes;
};

/*
 * The following helpers are used to convert a member of a struct into its parent.
 */

#define drm_crtc_to_skreen_output(target) \
	container_of(target, struct skreen_output, crtc)

#define drm_device_to_skreen_device(target) \
	container_of(target, struct skreen_device, drm)

#define to_skreen_crtc_state(target)\
	container_of(target, struct skreen_crtc_state, base)

#define to_skreen_plane_state(target)\
	container_of(target, struct skreen_plane_state, base.base)

/**
 * skreen_crtc_init() - Initialize a CRTC for VKMS
 * @dev: DRM device associated with the VKMS buffer
 * @crtc: uninitialized CRTC device
 * @primary: primary plane to attach to the CRTC
 * @cursor: plane to attach to the CRTC
 */
int skreen_crtc_init(struct drm_device *dev, struct drm_crtc *crtc,
		   struct drm_plane *primary, struct drm_plane *cursor);

/**
 * skreen_output_init() - Initialize all sub-components needed for a SKREEN device.
 *
 * @vkmsdev: SKREEN device to initialize
 */
int skreen_output_init(struct skreen_device *vkmsdev);

/**
 * skreen_plane_init() - Initialize a plane
 *
 * @vkmsdev: SKREEN device containing the plane
 * @type: type of plane to initialize
 */
struct skreen_plane *skreen_plane_init(struct skreen_device *vkmsdev,
				   enum drm_plane_type type);

/* CRC Support */
const char *const *skreen_get_crc_sources(struct drm_crtc *crtc,
					size_t *count);
int skreen_set_crc_source(struct drm_crtc *crtc, const char *src_name);
int skreen_verify_crc_source(struct drm_crtc *crtc, const char *source_name,
			   size_t *values_cnt);

/* Composer Support */
void skreen_composer_worker(struct work_struct *work);
void skreen_set_composer(struct skreen_output *out, bool enabled);
void skreen_writeback_row(struct skreen_writeback_job *wb, const struct line_buffer *src_buffer, int y);

/* Writeback */
int skreen_enable_writeback_connector(struct skreen_device *vkmsdev);

/**
 * skreen_output_add_mode() - Add a resolution to the connector's mode list
 *
 * @vkmsdev: SKREEN device to add the resolution to
 * @width: width in pixels, already validated against XRES_MIN/XRES_MAX
 * @height: height in pixels, already validated against YRES_MIN/YRES_MAX
 *
 * Returns: 0 on success, -EEXIST if the resolution is already offered
 * (built-in preset or previously added), -ENOSPC if the list is full.
 */
int skreen_output_add_mode(struct skreen_device *vkmsdev, u16 width, u16 height);

#endif /* _VKMS_DRV_H_ */
