// SPDX-License-Identifier: GPL-2.0+

/**
 * DOC: skreen (SKreen Driver)
 *
 * SKREEN is a software-only model of a KMS driver that is useful for testing
 * and for running X (or similar) on headless machines. SKREEN aims to enable
 * a virtual display with no need of a hardware display capability, releasing
 * the GPU in DRM API tests.
 */

#include <linux/module.h>
#include <linux/platform_device.h>
#include <linux/dma-mapping.h>

#include <drm/clients/drm_client_setup.h>
#include <drm/drm_gem.h>
#include <drm/drm_atomic.h>
#include <drm/drm_atomic_helper.h>
#include <drm/drm_drv.h>
#include <drm/drm_fbdev_shmem.h>
#include <drm/drm_file.h>
#include <drm/drm_gem_framebuffer_helper.h>
#include <drm/drm_ioctl.h>
#include <drm/drm_managed.h>
#include <drm/drm_probe_helper.h>
#include <drm/drm_gem_shmem_helper.h>
#include <drm/drm_vblank.h>

#include "skreen_drv.h"
#include "skreen_drm.h"

#include <drm/drm_print.h>
#include <drm/drm_debugfs.h>

#define DRIVER_NAME	"skreen"
#define DRIVER_DESC	"Virtual Kernel Mode Setting"
#define DRIVER_MAJOR	1
#define DRIVER_MINOR	0

static struct skreen_config *default_config;

DEFINE_DRM_GEM_FOPS(skreen_driver_fops);

static void skreen_release(struct drm_device *dev)
{
	struct skreen_device *vkms = drm_device_to_skreen_device(dev);

	if (vkms->output.composer_workq)
		destroy_workqueue(vkms->output.composer_workq);
}

static void skreen_atomic_commit_tail(struct drm_atomic_state *old_state)
{
	struct drm_device *dev = old_state->dev;
	struct drm_crtc *crtc;
	struct drm_crtc_state *old_crtc_state;
	int i;

	drm_atomic_helper_commit_modeset_disables(dev, old_state);

	drm_atomic_helper_commit_planes(dev, old_state, 0);

	drm_atomic_helper_commit_modeset_enables(dev, old_state);

	drm_atomic_helper_fake_vblank(old_state);

	drm_atomic_helper_commit_hw_done(old_state);

	drm_atomic_helper_wait_for_flip_done(dev, old_state);

	for_each_old_crtc_in_state(old_state, crtc, old_crtc_state, i) {
		struct skreen_crtc_state *skreen_state = to_skreen_crtc_state(old_crtc_state);

		flush_work(&skreen_state->composer_work);
	}

	drm_atomic_helper_cleanup_planes(dev, old_state);
}

static int skreen_config_show(struct seq_file *m, void *data)
{
	struct drm_debugfs_entry *entry = m->private;
	struct drm_device *dev = entry->dev;
	struct skreen_device *vkmsdev = drm_device_to_skreen_device(dev);

	seq_printf(m, "writeback=%d\n", vkmsdev->config->writeback);
	seq_printf(m, "cursor=%d\n", vkmsdev->config->cursor);
	seq_printf(m, "overlay=%d\n", vkmsdev->config->overlay);

	return 0;
}

static const struct drm_debugfs_info skreen_config_debugfs_list[] = {
	{ "skreen_config", skreen_config_show, 0 },
};

/*
 * DRM_IOCTL_SKREEN_SET_ENABLED - Enable or disable the virtual monitor.
 *
 * Reachable directly through the DRM device fd. Any client holding an
 * open fd can call this, master or not, so it also works while a
 * compositor (Xorg/Wayland) already holds DRM master.
 */
static int skreen_set_enabled_ioctl(struct drm_device *dev, void *data,
				     struct drm_file *file_priv)
{
	struct skreen_device *skreen_dev = drm_device_to_skreen_device(dev);
	struct drm_skreen_enable *args = data;
	struct drm_connector *connector = &skreen_dev->output.connector;
	enum drm_connector_status old_status;

	/* detect()/get_modes() read this under mode_config.mutex during probes */
	mutex_lock(&dev->mode_config.mutex);
	skreen_dev->enabled = !!args->enabled;

	/*
	 * Run a full probe (detect() + get_modes()) so both the cached status
	 * and the cached mode list are up to date before userspace is
	 * notified. Compositors such as mutter may re-read the connector
	 * without forcing a probe (DRM_IOCTL_MODE_GETCONNECTOR with count_modes
	 * set), so updating only the status would expose a connected
	 * connector with no modes, which gets ignored.
	 */
	old_status = connector->status;
	connector->funcs->fill_modes(connector, dev->mode_config.max_width,
				     dev->mode_config.max_height);
	mutex_unlock(&dev->mode_config.mutex);

	if (connector->status != old_status)
		drm_kms_helper_connector_hotplug_event(connector);

	return 0;
}

/*
 * DRM_IOCTL_SKREEN_GET_ENABLED - Query whether the virtual monitor is
 * currently enabled.
 */
static int skreen_get_enabled_ioctl(struct drm_device *dev, void *data,
				     struct drm_file *file_priv)
{
	struct skreen_device *skreen_dev = drm_device_to_skreen_device(dev);
	struct drm_skreen_enable *args = data;

	args->enabled = skreen_dev->enabled ? 1 : 0;

	return 0;
}

/*
 * DRM_IOCTL_SKREEN_ADD_RESOLUTION - Add a resolution to the list of modes
 * offered by the virtual monitor.
 *
 * Reachable directly through the DRM device fd, master or not. The active
 * resolution is not changed: the new mode is only appended to the list
 * reported by skreen_conn_get_modes(), so the user can pick it from their
 * display settings. Returns -EEXIST if the resolution is already offered.
 */
static int skreen_add_resolution_ioctl(struct drm_device *dev, void *data,
					struct drm_file *file_priv)
{
	struct skreen_device *skreen_dev = drm_device_to_skreen_device(dev);
	struct drm_skreen_resolution *args = data;
	int ret;

	if (args->width < XRES_MIN || args->width > XRES_MAX) {
		drm_err(dev, "resolution width %u out of range [%d, %d]\n",
			args->width, XRES_MIN, XRES_MAX);
		return -EINVAL;
	}

	if (args->height < YRES_MIN || args->height > YRES_MAX) {
		drm_err(dev, "resolution height %u out of range [%d, %d]\n",
			args->height, YRES_MIN, YRES_MAX);
		return -EINVAL;
	}

	ret = skreen_output_add_mode(skreen_dev, args->width, args->height);
	if (ret)
		return ret;

	/* Trigger hotplug detection so clients re-probe the mode list */
	drm_kms_helper_hotplug_event(dev);

	return 0;
}

static const struct drm_ioctl_desc skreen_ioctls[] = {
	DRM_IOCTL_DEF_DRV(SKREEN_SET_ENABLED, skreen_set_enabled_ioctl, DRM_RENDER_ALLOW),
	DRM_IOCTL_DEF_DRV(SKREEN_GET_ENABLED, skreen_get_enabled_ioctl, DRM_RENDER_ALLOW),
	DRM_IOCTL_DEF_DRV(SKREEN_ADD_RESOLUTION, skreen_add_resolution_ioctl, DRM_RENDER_ALLOW),
};

static const struct drm_driver skreen_driver = {
	.driver_features	= DRIVER_MODESET | DRIVER_ATOMIC | DRIVER_GEM,
	.release		= skreen_release,
	.fops			= &skreen_driver_fops,
	DRM_GEM_SHMEM_DRIVER_OPS,
	DRM_FBDEV_SHMEM_DRIVER_OPS,

	.ioctls			= skreen_ioctls,
	.num_ioctls		= ARRAY_SIZE(skreen_ioctls),

	.name			= DRIVER_NAME,
	.desc			= DRIVER_DESC,
	.major			= DRIVER_MAJOR,
	.minor			= DRIVER_MINOR,
};

static int skreen_atomic_check(struct drm_device *dev, struct drm_atomic_state *state)
{
	/* Delegate to standard atomic helper for validation */
	return drm_atomic_helper_check(dev, state);
}

static const struct drm_mode_config_funcs skreen_mode_funcs = {
	.fb_create = drm_gem_fb_create,
	.atomic_check = skreen_atomic_check,
	.atomic_commit = drm_atomic_helper_commit,
};

static const struct drm_mode_config_helper_funcs skreen_mode_config_helpers = {
	.atomic_commit_tail = skreen_atomic_commit_tail,
};

static int skreen_modeset_init(struct skreen_device *vkmsdev)
{
	struct drm_device *dev = &vkmsdev->drm;
	int ret;

	ret = drmm_mode_config_init(dev);
	if (ret)
		return ret;

	dev->mode_config.funcs = &skreen_mode_funcs;
	dev->mode_config.min_width = XRES_MIN;
	dev->mode_config.min_height = YRES_MIN;
	dev->mode_config.max_width = XRES_MAX;
	dev->mode_config.max_height = YRES_MAX;
	dev->mode_config.cursor_width = 512;
	dev->mode_config.cursor_height = 512;
	/*
	 * FIXME: There's a confusion between bpp and depth between this and
	 * fbdev helpers. We have to go with 0, meaning "pick the default",
	 * which is XRGB8888 in all cases.
	 */
	dev->mode_config.preferred_depth = 0;
	dev->mode_config.helper_private = &skreen_mode_config_helpers;

	ret = skreen_output_init(vkmsdev);
	if (ret)
		return ret;

	/*
	 * Required by drm_helper_hpd_irq_event(). The connector is HPD-only,
	 * so no periodic polling work is scheduled.
	 */
	drmm_kms_helper_poll_init(dev);

	return 0;
}

static int skreen_create(struct skreen_config *config)
{
	int ret;
	struct platform_device *pdev;
	struct skreen_device *skreen_device;

	pdev = platform_device_register_simple(DRIVER_NAME, -1, NULL, 0);
	if (IS_ERR(pdev))
		return PTR_ERR(pdev);

	if (!devres_open_group(&pdev->dev, NULL, GFP_KERNEL)) {
		ret = -ENOMEM;
		goto out_unregister;
	}

	skreen_device = devm_drm_dev_alloc(&pdev->dev, &skreen_driver,
					 struct skreen_device, drm);
	if (IS_ERR(skreen_device)) {
		ret = PTR_ERR(skreen_device);
		goto out_devres;
	}
	skreen_device->platform = pdev;
	skreen_device->config = config;
	skreen_device->enabled = false; /* Hidden until DRM_IOCTL_SKREEN_SET_ENABLED */
	config->dev = skreen_device;

	ret = dma_coerce_mask_and_coherent(skreen_device->drm.dev,
					   DMA_BIT_MASK(64));

	if (ret) {
		drm_err(&skreen_device->drm, "Could not initialize DMA support\n");
		goto out_devres;
	}

	ret = drm_vblank_init(&skreen_device->drm, 1);
	if (ret) {
		drm_err(&skreen_device->drm, "Failed to vblank\n");
		goto out_devres;
	}

	ret = skreen_modeset_init(skreen_device);
	if (ret)
		goto out_devres;

	drm_debugfs_add_files(&skreen_device->drm, skreen_config_debugfs_list,
			      ARRAY_SIZE(skreen_config_debugfs_list));

	ret = drm_dev_register(&skreen_device->drm, 0);
	if (ret)
		goto out_devres;

	/* Trigger hotplug event to notify userspace of connector status */
	drm_kms_helper_hotplug_event(&skreen_device->drm);

	/* Setup initial framebuffer for the virtual display */
	drm_client_setup(&skreen_device->drm, NULL);

	return 0;

out_devres:
	devres_release_group(&pdev->dev, NULL);
out_unregister:
	platform_device_unregister(pdev);
	return ret;
}

static int __init skreen_init(void)
{
	int ret;
	struct skreen_config *config;

	config = kmalloc(sizeof(*config), GFP_KERNEL);
	if (!config)
		return -ENOMEM;

	default_config = config;

	config->cursor = true;
	config->writeback = true;
	config->overlay = false;

	ret = skreen_create(config);
	if (ret)
		kfree(config);

	return ret;
}

static void skreen_destroy(struct skreen_config *config)
{
	struct platform_device *pdev;

	if (!config->dev) {
		pr_info("skreen: skreen_device is NULL.\n");
		return;
	}

	pdev = config->dev->platform;

	drm_dev_unregister(&config->dev->drm);
	drm_atomic_helper_shutdown(&config->dev->drm);
	devres_release_group(&pdev->dev, NULL);
	platform_device_unregister(pdev);

	config->dev = NULL;
}

static void __exit skreen_exit(void)
{
	if (default_config->dev)
		skreen_destroy(default_config);

	kfree(default_config);
}

module_init(skreen_init);
module_exit(skreen_exit);

MODULE_AUTHOR("Lizardo Galvez <funnycode21@gmail.com>");
MODULE_DESCRIPTION(DRIVER_DESC);
MODULE_LICENSE("GPL");
MODULE_VERSION(SKREEN_DRIVER_VERSION);
